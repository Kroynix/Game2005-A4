The old image effects have been deprecated and moved to the Asset Store: https://www.assetstore.unity3d.com/#!/content/83913

We recommend that you now use the new post-processing stack. You'll find it at https://www.unity3d.com/postprocessing
